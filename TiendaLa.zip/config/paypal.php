<?php
return array(
    // set your paypal credential
    'client_id' => 'Af2dyEyIbkt7r4q07wm_PbPujLrMufokZybSNDuMFbbpLNcTvvkbRz9KPKrwoR4PiS45vtwzM4Sr9oAL',
    'secret' => 'EEVRn2wmArzEfM1sv2yjwQddDEbl2lzjbeEq6IvgKAnagb83q71J_aS7czhwASLb3VKdaY89mWVLwXid',

    /**
     * SDK configuration 
     */
    'settings' => array(
        /**
         * Available option 'sandbox' or 'live'
         */
        'mode' => 'sandbox',

        /**
         * Specify the max request time in seconds
         */
        'http.ConnectionTimeOut' => 30,

        /**
         * Whether want to log to a file
         */
        'log.LogEnabled' => true,

        /**
         * Specify the file that want to write on
         */
        'log.FileName' => storage_path() . '/logs/paypal.log',

        /**
         * Available option 'FINE', 'INFO', 'WARN' or 'ERROR'
         *
         * Logging is most verbose in the 'FINE' level and decreases as you
         * proceed towards ERROR
         */
        'log.LogLevel' => 'FINE'
    ),
);