@extends('store.template')

@section('content')

<div class="table-responsive">
				<h3>Datos del usuario</h3>
				<table class="table table-striped table-hover table-bordered">
					
				</table>
			</div>