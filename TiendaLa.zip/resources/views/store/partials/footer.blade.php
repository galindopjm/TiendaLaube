<footer class="container-fluid">
	<div class="row">
		<div class="col-md-4">
			<h3>Laube Cosmeticos</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque dolores ratione minus, voluptates dolore soluta harum. Nobis neque doloribus corrupti iusto rem beatae libero, incidunt animi nemo voluptatem dolores accusantium magni ad ipsum eum repellendus vero deleniti velit molestiae quaerat, veniam ducimus labore sapiente? Commodi ad, pariatur. Ab consectetur, quasi!</p>
		</div>
		<div class="col-md-4">
			<h3>Derechos:</h3>
			<div class="author-info">
				<img src="../img/laube.jpg" alt="" class="avatar">
				<p><a href="#">@ConsorcioLaube</a> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum excepturi possimus tempora porro, a est atque? Rem eaque, ullam, dolore fugit cupiditate odio ipsum fugiat quae, error accusantium corporis harum voluptatem perspiciatis dolorem pariatur iste id temporibus voluptatum enim dicta.</p>
			</div>
		</div>
		<div class="col-md-4">
			<h3>Siguenos</h3>
			<ul class="redes">
				<li>
					<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-twitter-square fa-2x"></i></a>
				</li>
				<li>
					<a href="#"><i class="fa fa-instagram fa-2x"></i></a>
				</li>
			</ul>
			<h3>Escribenos:</h3>
			<i class="fa fa-at"></i> <a href="#">consorciolaube@hotmail.com</a>
		</div>
	</div>
</footer>